import React from 'react';

const Card = ({ imageSrc, title, description, buttonText, onButtonClick }) => {
  return (
    <div className="card">
      <img src={imageSrc} className="card-img-top" alt="Card Image" />
      <div className="card-body">
        <h5 className="card-title">{title}</h5>
        <p className="card-text">{description}</p>
        <button className="btn btn-primary" onClick={onButtonClick}>
          {buttonText}
        </button>
      </div>
    </div>
  );
};

const CardList = () => {
  const handleButtonClick = () => {
    // Add your button click logic here
    console.log('Button Clicked!');
  };

  return (
    <div className="card-list">
      <Card
        imageSrc="https://example.com/image1.jpg"
        title="Card 1"
        description="This is the description for Card 1."
        buttonText="Click Me"
        onButtonClick={handleButtonClick}
      />
      <Card
        imageSrc="https://example.com/image2.jpg"
        title="Card 2"
        description="This is the description for Card 2."
        buttonText="Click Me"
        onButtonClick={handleButtonClick}
      />
      {/* Add more cards as needed */}
    </div>
  );
};

export default CardList;
