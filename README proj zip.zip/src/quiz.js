import React, { useState } from 'react';

const Read = () => {
  const [answers, setAnswers] = useState([]);
  
  const handleAnswer = (questionNumber, selectedOption) => {
    // Save the selected answer for each question
    setAnswers([...answers, { question: questionNumber, answer: selectedOption }]);
  };

  const renderQuizQuestion = (questionNumber, question, options) => (
    <div key={questionNumber}>
      <h3>Question {questionNumber + 1}: {question}</h3>
      <ul>
        {options.map((option, index) => (
          <li key={index}>
            <label>
              <input
                type="radio"
                name={`question${questionNumber}`}
                value={option}
                onChange={() => handleAnswer(questionNumber, option)}
              />
              {option}
            </label>
          </li>
        ))}
      </ul>
    </div>
  );

  const quizQuestions = [
    {
      question: "What is the capital of France?",
      options: ["Paris", "Berlin", "London", "Madrid"],
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Earth", "Mars", "Venus", "Jupiter"],
    },
    // Add more questions here...
  ];

  return (
    <div>
      <div id="carouselExampleAutoplaying" className="carousel slide" data-bs-interval="false">
        {/* ... Your carousel code ... */}
        <div>
      <div id="carouselExampleAutoplaying" className="carousel slide"  data-bs-interval="false">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700888086/carimg1_fs92jl.jpg"
              className="d-block w-100" height="400" alt="..." />
          </div>
          <div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700888194/carimg2_hib2ua.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>
            <div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700888249/carimg3_e3xnej.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>
			<div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700892155/carimg4_f8wrlx.jpg"
                    class="d-block w-100" height="400" alt="..."/> 
            </div>
			<div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700892817/carimg5_qgvcrs.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>
			<div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700892936/carimg6_rs9v2o.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>
			<div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700893012/carimg7_dyacml.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>
            <div class="carousel-item">
                <img src="https://res.cloudinary.com/djpqj3nhr/image/upload/v1700893012/carimg7_dyacml.jpg"
                    class="d-block w-100" height="400" alt="..."/>
            </div>

        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
      <h1>Did we get it right??</h1>


	  </div>
      </div>
      <h1>Did we get it right?</h1>

      <div>
        {quizQuestions.map((quiz, index) => renderQuizQuestion(index, quiz.question, quiz.options))}
      </div>

      {/* You can display the answers or do something with them */}
      {answers.length > 0 && (
        <div>
          <h2>Answers:</h2>
          <ul>
            {answers.map((answer, index) => (
              <li key={index}>
                Question {answer.question + 1}: {answer.answer}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Read;
