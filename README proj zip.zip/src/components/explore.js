import React from "react"; 
import { Link } from "react-router-dom";

const Features = () => {
    return ( 
        <div className="container mt-4">
        <div className="row row-cols-1 row-cols-md-2 g-6">
            <div className="col-md-4">
                <div className="card">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAq1BMVEXY19r///8AAAD/UCM+PUK+vr7f3uGpqamCgoQzMjZWVldubW9SUlPVQx0fHyJqamvCPRuGKhKenqA4NzwPDxAlJShcHQ3GxcjdRR7KPxzj4+Py8vLX19dcXF1hHg11dHZJFwrjRx+1tLegMhbDw8MdHB/R0dE0NDWHhogwDwa1ORmVLxU/FAnwSyFoIA5MGAp/KBIWFhcrKy5CQkMRBQOdMRY4EQi3OhmrNRiIFNFdAAAGCklEQVR4nO2da1viOhRGCz0EBIQRcdByKVa5jJfR0XPx//+yQ6dJaaEFku6Qvp2sbxFp9np20gTSBKdWdRzTAWjHGuJjDfGxhvhYQ3ysIT7WEB9riI81xMca4mMN8bGG+KQNJ48NfB4neYZeq14VWl6G4dg3HRYp/njXkPVMx0TMgqUNPdMBacBLGo6HpsPRwHCcMOyYjkYLna3hJP7jcNFDZ7Ftj5PYUNxGhxd/VYEL4ejHhkLQdGhkCEVhuOTla9OBkXHNjZbcMEik8HoxDLnh/xmVelmlUsOTGHDDZlQMIxfyXDe7VDca/Enw+UszbRjm7Vds8ZEqha8tUqVyc5NruB1Mwoxu77uLVOmX4fiPk2+4tUiXQt9tRheG4z9OvuFHbHG9V7qIS+UfNvMNxUt87E+XuPDww1zkp3LAcHPLDIn/9VCpxBw0rAR/qmHvojpkj/gVxBriYw3x+eMMV+3qsMo0XHusKnjrTMMWc6oCa1lDdKwhPtYQH2uIjzXExxriYw3xsYb4WEN8rCE+1lD1spSUzpA5o+ba71Phr5sjp0g41Ias0fqsU/PZaqgHRGvIgja5XkRX1ZHUkC37mvxCpku1oAgNWVPvI+LDplJUdIZsrdUvZK0SFpkhO8c2G189rsKGqQz+mD0/faPh6Xn2I3Fl+SxSGbLE4vHPS5eWy5/bi0v3RSrDUXyTmd8S+4XczsXlhyMzhmwqIrjS4BdyJSqYyoZGYxiI+r80Cbrul6giMGHIxETtWZug6z7zOj4lYyMxbPDK3zQKuu4br6VxfkMmthK9ajW857XIDYo0OeSPcL5rFXTd96iaG6nYSAxFI9UxTiS5VWmmFIZsEL3pRbOg675EFQ2koqMw9A810tvvm1kOUXbfFToiiSEf7jPHwte/f79GM5PjY6LUoE9iyD/X32UF9Q/vO/UZQR7voku1z27Yjd6UmaZ4tlWvfy/seBldqFtWw+J5LL9h0f6IYFisrWIYbtqqch5RDNXbapkNW9O0o9o9p8yGA2+08224Sn8stSFzWGM3j9JtteSGzr6jbH8svWHoWKitAhhm5FHGEcIww/H0/ghiWMARxlC5rQIZKuYRylBp7AAzzMrjkbYKZ7h5q9xcDtBQsj9CGkr1R1BDibkcrGGGY/YyHbDhflvNvBi0YeiYfKIqc7Uc3XDpV9qQjdIH32YuEQAbstHOoaLZj3TAGrLljt+/mRmENdzL3zzHD9Rwt/8d8IM0lMgfpOGe38tBPzjDvfb5dsQPzHDf79sxPyjDPb9j7RPMULr/gRlKjQ+Ahnv5O35/gTI8eX4Gaig5vsMZFuh/EIZe0fyV3XCtNP4hGRbPH5LhKfMzZEO19oljqNo+UQyL+ZXfsKifQcNDT0GLvTyS87NsjD0FffBJdqr8hRh7kv3gboTLF7nPD4cwthuB7yiZ58T1SrYdiu+zPPuOknj34T2VSQ5ia5fUDkSanV386Hpd+0cF/L7ck4qNZneeWPjTuzuP37TqHbngSHIomulMq+FMpZFS7ZLlZ2bXHzQKPvA6VpKx0RjGu/GftAn+J6qQ3JFPtVu9K+p/0CQoMig3ZaMzdEYigPpMx+3mdRZf39CJA/GoH3JFPS7eJ6bvUqM9peF2P3fI/P3r7pKGu6/3eeLKCoHRnd6i83whQV8hLsITePQfUKNwPA3tKUqD/NhIkO6D1IYOG3XzwytMd6QWFPFpZs1VfoiFWCkdg0Vv6DAWdOh/1rvXCVQD0nOqYDDwp+0uDe2pPwhKdapgdFVaisViT/eExxriYw3xsYb4WEN8rCE+1hAfa4iPNcQnx1Dlq9eSIpYbhGEQFSVXIcuMWL0NuOEyKkqvYZUXcXzskhvWeHlV5Au8EsEc8RV1TRiKRbJVQP2doAmcQAj6seGkLlj1O+j0t2sMk9iwtvNIfUX4nUJuONb7QyNmGI4ThjXPdDga8GpJw5p3YzogYnqsljasjf3j7wLCH9d2DTdpPMePxpyHlrfVShhuYI8NfB5ZyiltWEWsIT7WEB9riI81xMca4mMN8bGG+FhDfKwhPtYQH2uIT/UN/wd1yoadgWl0mgAAAABJRU5ErkJggg==" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body">
                        <div className="d-grid gap-2">
                            <a href="#knr" class="btn btn-primary">VIDEOS</a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYaIi3fme-Gp29CUGvVU4C4I2YSY9zRjs4sQ&usqp=CAU" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body text-center">
                        <div className="d-grid gap-2">
                            <a href="#knr" className="btn btn-primary">AUDIO</a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJERsEVYd3OIe5S7B6-tfeaoZNhxx8Ck8SaA&usqp=CAU" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body text-center">
                        <div className="d-grid gap-2">
                            <Link to="/games" className="btn btn-primary">GAMES</Link>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3a4TAyVzCP-QTzmXxvN3woXgKdZJygyyfiQ&usqp=CAU" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body text-center">
                        <div className="d-grid gap-2">
                            <a href="#knr" className="btn btn-primary">QUIZ</a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzZJk97erKpMDZIqVLVX871eWcsZN4lkDJJg&usqp=CAU" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body text-center">
                        <div className="d-grid gap-2">
                            <Link to="/Read" className="btn btn-primary">READ ALONG...</Link>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className="card">
                    <img src="https://www.voicesofyouth.org/sites/voy/files/images/2020-11/img_20200208_102313-2_0.jpg" className="card-img-top" height="230" alt="..."/>
                    <div className="card-body text-center">
                        <div className="d-grid gap-2">
                            <Link to="/Card" className="btn btn-primary">KNOW YOUR RIGHTS</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     );
}
 
export default Features;