import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <section id="background-image">
        <img src="https://www.wallpapertip.com/wmimgs/72-726923_background-colors-for-kids.jpg" alt="Background" />
        <div className="container mt-5">
          <div className="row justify-content-end">
            <div className="col-md-6 offset-md-3">
              <div className="card login-block">
                <div className="card-body">
                  <h3 className="card-title text-center mb-4">Let's Start!</h3>
                    <div className="form-group">
                      <label htmlFor="name">Name</label>
                      <input type="text" className="form-control" id="name" placeholder="Enter your name" />
                    </div>
                    <div className="form-group mt-3"> 
                      <label htmlFor="age">Age</label>
                      <input type="number" className="form-control" id="age" placeholder="Enter your age" />
                    </div>
                    <div className="d-flex justify-content-center mt-3"> 
                    <Link to="/explore" className="btn btn-primary">Explore!</Link> 
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

  