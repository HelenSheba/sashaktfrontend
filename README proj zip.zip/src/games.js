import React from 'react';

const Games = () => {
  return ( 
    <div>
      <div id="carouselExampleAutoplaying" className="carousel slide" data-bs-ride="carousel" data-bs-interval="1500">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="https://images.unsplash.com/photo-1603354351226-d82bd4a635a3?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGNoaWxkcmVuJTIwcGxheWluZyUyMGdhbWVzfGVufDB8fDB8fHww"
              className="d-block w-100" height="300" alt="..." />
          </div>
          <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1615680022647-99c397cbcaea?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8b25saW5lJTIwZ2FtZXN8ZW58MHx8MHx8fDA%3D"
                    class="d-block w-100" height="300" alt="..."/>
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1623934199716-dc28818a6ec7?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b25saW5lJTIwZ2FtZXN8ZW58MHx8MHx8fDA%3D"
                    class="d-block w-100" height="300" alt="..."/>
            </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
      <h1>Time to kick it up a notch !!!</h1>
      <div className="card-group">
      <div className="card">
          <img src="https://images.unsplash.com/photo-1528747264996-5002f379b5f3?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d29yZCUyMHB1enpsZSUyMGdhbWV8ZW58MHx8MHx8fDA%3D" className="card-img-top" height="250" alt="..."/>
          <div className="d-grid gap-2">
            <a href="#top" className="btn btn-success">WORD FORMATION</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.unsplash.com/photo-1612611741189-a9b9eb01d515?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGppZ3NhdyUyMHB1enpsZSUyMGdhbWV8ZW58MHx8MHx8fDA%3D" className="card-img-top" height="250" alt="..."/>
          <div className="d-grid gap-2">
            <a href="#top" className="btn btn-success">JIGSAW PUZZLE</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.unsplash.com/photo-1650504149601-f9fdd445c187?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8cGFpbnRpbmclMjBnYW1lJTIwZm9yJTIwY2hpbGRyZW58ZW58MHx8MHx8fDA%3D" className="card-img-top" height="250" alt="..."/>
          <div className="d-grid gap-2">
            <a href="#top" className="btn btn-success">PAINTING GAME</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.unsplash.com/photo-1617289755070-3590b660a06e?auto=format&fit=crop&q=60&w=500&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Z2FtZSUyMHdpdGglMjBhbmltYXRlZCUyMGNoYXJhY3RlcnxlbnwwfHwwfHx8MA%3D%3D" className="card-img-top" height="250" alt="..."/>
          <div className="d-grid gap-2">
            <a href="#top" className="btn btn-success">ANIMATED CHARACTER</a>
          </div>
        </div>
      </div>
      </div>
  );
}

export default Games;

