import React, { useState } from 'react';

const Read = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState([]);

  const handleAnswer = (selectedOption) => {
    // Save the selected answer for the current question
    setAnswers([...answers, { question: currentQuestion, answer: selectedOption }]);
    // Move to the next question
    setCurrentQuestion(currentQuestion + 1);
  };

  const renderQuizQuestion = (questionNumber, question, options) => (
    <div key={questionNumber} style={{ display: currentQuestion === questionNumber ? 'block' : 'none' }}>
      <h3>Question {questionNumber + 1}: {question}</h3>
      <ul>
        {options.map((option, index) => (
          <li key={index}>
            <label>
              <input
                type="radio"
                name={`question${questionNumber}`}
                value={option}
                onChange={() => handleAnswer(option)}
              />
              {option}
            </label>
          </li>
        ))}
      </ul>
      {currentQuestion < quizQuestions.length - 1 && (
        <button onClick={() => setCurrentQuestion(currentQuestion + 1)}>Next Question</button>
      )}
    </div>
  );

  const renderAnswersGrid = () => (
    <div>
      <h2>Answers:</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
        {answers.map((answer, index) => (
          <div key={index}>
            <strong>Question {answer.question + 1}:</strong> {answer.answer}
          </div>
        ))}
      </div>
    </div>
  );

  const quizQuestions = [
    {
      question: "What is the capital of France?",
      options: ["Paris", "Berlin", "London", "Madrid"],
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Earth", "Mars", "Venus", "Jupiter"],
    },
    // Add more questions here...
  ];

  return (
    <div>
      <div id="carouselExampleAutoplaying" className="carousel slide" data-bs-interval="false">
        {/* ... Your carousel code ... */}
      </div>
      <h1>Did we get it right??</h1>

      <div>
        {quizQuestions.map((quiz, index) => renderQuizQuestion(index, quiz.question, quiz.options))}
      </div>

      {answers.length > 0 && renderAnswersGrid()}
    </div>
  );
};

export default Read;
