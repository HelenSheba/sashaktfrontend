import './App.css';
import {Route, Routes } from 'react-router-dom';
import React from 'react'; 
import Home from './components/Home';
import Navbar from './components/MyNav';
import Features from './components/explore';
import Games from './games';
import Read from './Read';

function App() {
  return (
    <div className='App'>
      <div>
        <Navbar/>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/explore" element={<Features/>}/>
          <Route path="/games" element={<Games/>}/>
          <Route path="/Read" element={<Read/>}/>
          <Route path="/Card" element={<Card/>}/>
        </Routes>
      </div>
    </div>
  );
}

export default App;


